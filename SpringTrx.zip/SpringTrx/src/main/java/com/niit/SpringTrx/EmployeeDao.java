package com.niit.SpringTrx;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.omg.CORBA.TIMEOUT;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class EmployeeDao {
	HibernateTemplate template;  
	public void setTemplate(HibernateTemplate template) {  
	    this.template = template;  
	}  
	//method to save employee  
	@Transactional(propagation=Propagation.REQUIRED,isolation=Isolation.SERIALIZABLE)
	public void saveEmployee(Employee e){ 
		template.setCheckWriteOperations(false);
		//template.getSessionFactory().getCurrentSession().beginTransaction();
		
		template.saveOrUpdate(e);
	}  
	//method to update employee  
	public void updateEmployee(Employee e){  
	    template.update(e);  
	}  
	//method to delete employee  
	public void deleteEmployee(Employee e){  
	    //template.delete(e);  
	}  
	//method to return one employee of given id  
	public Employee getById(int id){  
	    //Employee e=(Employee)template.get(Employee.class,id);  
	    //return e;
		return null;
	}  
	//method to return all employees  
	@Transactional(readOnly=true,timeout=1000)
	public List<Employee> getEmployees(){  
	    List<Employee> list=new ArrayList<Employee>();  
	    list=template.loadAll(Employee.class);  
	    return list;  
	}  
}
