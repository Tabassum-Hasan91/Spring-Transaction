package com.niit.SpringTrx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClaz {
	public static void main(String[] args) {  
	      
	    ApplicationContext a=new ClassPathXmlApplicationContext("applicationContext.xml");
	    
	    EmployeeDao dao=(EmployeeDao)a.getBean("d");  
	      
	    Employee e=new Employee();  
	    e.setId(13);  
	    e.setName("Xyz");  
	    e.setSalary(50000);  
	      
	    dao.saveEmployee(e); 
	    //dao.updateEmployee(e);
	    System.out.println("Done");
	}  
}

